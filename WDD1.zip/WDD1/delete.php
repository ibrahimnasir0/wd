<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM user WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "User deleted successfully";
} else {
    echo "Error deleting user: " . $conn->error;
}

$conn->close();

header("Location: index.php");
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="container">
        <?php
        require_once "database.php";
        // if (isset($_POST["submit"])) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fullname = $_POST["fullname"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            // $passwordrepeat = $_POST["repeat_password"];

            $sql = "INSERT INTO users(full_name ,email, password) VALUES('$fullname', '$email', '$password')";
            if($conn->query($sql) == TRUE){
                echo " Registration Successfull ";
            }else {
                echo "Error : " .$sql."<br> " .$conn->error;
            }
        }


        ?>
        <form action="newregistration.php" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="fullname" placeholder="Name: ">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Email: ">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password: ">
            </div>
            <div class="form-group">
                <input type="repeatpassword" class="form-control" name="repeatpassword" placeholder="Repeat Password">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Register" name="Submit">
            </div>
        </form>
    </div>
</body>
</html>
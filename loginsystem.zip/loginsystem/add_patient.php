<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location: login.php");
  exit;
}

include 'partials/_dbconnect.php';

$showAlert = false;
$showError = false;

if($_SERVER["REQUEST_METHOD"] == "POST"){
  $patientName = $_POST["patientName"];
  $age = $_POST["age"];
  $contact = $_POST["contact"];
  $address = $_POST["address"];
  $symptoms = $_POST["symptoms"];

  $sql = "INSERT INTO `patients` (`name`, `age`, `contact`, `address`, `symptoms`, `dt`) VALUES ('$patientName', '$age', '$contact', '$address', '$symptoms', current_timestamp())";
  $result = mysqli_query($conn, $sql);

  if($result){
    $showAlert = true;
  } else {
    $showError = "Error adding patient record";
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaxtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Add Patient</title>
  </head>
  <body>
    <?php require 'partials/_nav.php' ?>

    <div class="container my-4">
      <h1 class="text-center">Add Patient Record</h1>
      <form action="/loginsystem/add_patient.php" method="post">
        <div class="form-group">
          <label for="patientName">Patient Name</label>
          <input type="text" class="form-control" id="patientName" name="patientName" required>
        </div>
        <div class="form-group">
          <label for="age">Age</label>
          <input type="number" class="form-control" id="age" name="age" required>
        </div>
        <div class="form-group">
          <label for="contact">Contact Number</label>
          <input type="tel" class="form-control" id="contact" name="contact" required>
        </div>
        <div class="form-group">
          <label for="address">Address</label>
          <textarea class="form-control" id="address" name="address" rows="3"></textarea>
        </div>
        <div class="form-group">
          <label for="symptoms">Symptoms</label>
          <textarea class="form-control" id="symptoms" name="symptoms" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Add Patient</button>
      </form>

      <?php
      if($showAlert){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> Patient record added successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>';
      }
      if($showError){
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Error!</strong> '. $showError .'
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </

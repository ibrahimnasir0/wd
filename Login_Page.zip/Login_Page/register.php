<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = $_POST["new_username"];
    $new_password = $_POST["new_password"];

    $sql = "INSERT INTO user (username, password) VALUES ('$new_username', '$new_password')";
    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
</head>
<body>
    <h2>Register</h2>
    <form action="register.php" method="post">
        <label for="new_username">New Username:</label>
        <input type="text" name="new_username" required><br>

        <label for="new_password">New Password:</label>
        <input type="password" name="new_password" required><br>

        <input type="submit" value="Register">
    </form>

    <p>Already have an account? <a href="index.html">Login here</a>.</p>
</body>
</html>
